package com.learn.SpringBoot.DependencyInjection;

import org.springframework.stereotype.Component;

@Component
public class OfflineOrder implements Order {

}
